# -*- coding: utf-8 -*-
#------------------------------------------------------------
# pelisalacarta - XBMC Plugin
# Canal para TUGOLEADA
# http://blog.tvalacarta.info/plugin-xbmc/pelisalacarta/
#------------------------------------------------------------
import re

from core import scrapertools
from core import logger
from core import config
from core.item import Item

__channel__ = "tugoleada"

host ="http://tugoleada.com/"


def mainlist(item):
    logger.info("pelisalacarta.channels.tugoleada mainlist")
    itemlist = []

    itemlist.append(Item(channel=__channel__, title="Agenda/Directos", action="entradas", url=host, thumbnail="http://i.imgur.com/DegBUpj.png",fanart="http://i.imgur.com/bCn8lHB.jpg?1"))
    itemlist.append(Item(channel=__channel__, title="Canales Acestream", action="canales", url=host+"index.php", thumbnail="http://i.imgur.com/DegBUpj.png",fanart="http://i.imgur.com/bCn8lHB.jpg?1", extra="AceStream"))
    itemlist.append(Item(channel=__channel__, title="Canales Sopcast", action="canales", url=host+"index.php", thumbnail="http://i.imgur.com/DegBUpj.png",fanart="http://i.imgur.com/bCn8lHB.jpg?1", extra="SopCast"))
    itemlist.append(Item(channel=__channel__, title="Canales Web/Html5", action="canales", url=host+"index.php", thumbnail="http://i.imgur.com/DegBUpj.png",fanart="http://i.imgur.com/bCn8lHB.jpg?1", extra="WEB"))

    return itemlist


def canales(item):
    logger.info("pelisalacarta.channels.tugoleada canales")
    itemlist = []

    data = scrapertools.cachePage(item.url)
    data = re.sub(r"\n|\r|\t|\s{2}|&nbsp;","",data)
    bloque = scrapertools.find_single_match(data, item.extra+'(.*?)</ul></li>')
    patron = '<a href="([^"]+)">(.*?)</a>'
    matches = scrapertools.find_multiple_matches(bloque, patron)

    for scrapedurl, scrapedtitle  in matches:
        scrapedurl = host + scrapedurl
        scrapedtitle = "[COLOR darkorange]"+scrapedtitle.strip()+"[/COLOR] [COLOR green]["+ \
                       item.title.replace('Canales ','')+"][/COLOR]"
        itemlist.append(Item(channel=__channel__, title=scrapedtitle, action="play", url=scrapedurl, thumbnail=item.thumbnail, fanart=item.fanart, folder=False))

    return itemlist


def entradas(item):
    logger.info("pelisalacarta.channels.tugoleada entradas")
    itemlist = []

    data = scrapertools.cachePage(item.url)
    data = re.sub(r"\n|\r|\t|\s{2}|&nbsp;","", data)
    bloque = scrapertools.find_multiple_matches(data, '<tr><td class="auto-style3"(.*?)</tr>')
    for match in bloque:
        patron = '(\d+/\d+/\d+).*?(\d+:\d+)\s*CET.*?>([^<]+)</td>.*?>([^<]+)</td>.*?>([^<]+)</td>.*?>(\d+-\d+|\d+)'
        matches = scrapertools.find_multiple_matches(match, patron)      

        for fecha, hora, deporte, competicion, evento, canal in matches:
            evento = "[COLOR darkorange][B]"+deporte+"/"+competicion+"/"+evento+"[/B][/COLOR]"
            scrapedtitle = "[COLOR green][B]"+fecha+" "+hora.strip()+"[/B][/COLOR] " + evento
            itemlist.append( Item(channel=__channel__, title=scrapedtitle, action="do_nothing", url="", thumbnail=item.thumbnail, fanart= item.fanart, folder=False) )
            if "-" in canal:
                canales = canal.split("-")
            else:
                canales = [canal]
            for c in canales:
                url = "http://tugoleada.com/canal" + c
                if int(c) < 9: p2p = "Web/Flash"
                elif int(c) >= 9 and int(c) < 16: p2p = "Acestream"
                else: p2p = "Sopcast"
                scrapedtitle = "      [COLOR green]CANAL "+c+" [/COLOR][COLOR indianred][" \
                           +p2p+"][/COLOR]"
                itemlist.append( Item(channel=__channel__, title=scrapedtitle, action="play", url=url, thumbnail=item.thumbnail, fanart=item.fanart, fulltitle=evento, folder=False) )

    return itemlist


def do_nothing(item):
    return


def play(item):
    itemlist = []
    data = scrapertools.cachePage(item.url)
    if "Web" in item.title:
        url = scrapertools.find_single_match(data, "(?:source|file):\s*['\"]([^'\"]+)['\"]") + "|Referer="+item.url
        itemlist.append(Item(channel=__channel__, title=item.title, server="directo", url=url, action="play", folder=False))
    else:
        url = scrapertools.find_single_match(data, 'Abrir canal en.*?href="([^"]+)"')
        url += "|"+item.fulltitle 
        itemlist.append(Item(channel=__channel__, title=item.title, server="p2p", url=url, action="play", folder=False))

    return itemlist
