# -*- coding: utf-8 -*-
# ------------------------------------------------------------
# Canal (javabc) por Hernan_Ar_c
# ------------------------------------------------------------

import urlparse,urllib2,urllib,re
import os, sys


from core import logger
from core import config
from core import scrapertools
from core.item import Item
from core import servertools

__channel__ = "javuncen"
__category__ = "S"
__type__ = "generic"
__title__ = "javuncen"
__language__ = "ES"

DEBUG = config.get_setting("debug")

host='http://javuncen.me'

def isGeneric():
    return True


def mainlist(item):

    logger.info("pelisalacarta.channels.javuncen mainlist")
    itemlist = []
    itemlist.append( Item(channel=__channel__, title="POPULAR", action="lista", url=host+'/popular'))
    itemlist.append( Item(channel=__channel__, title="RECIENTE", action="lista", url=host+'/recent'))
    itemlist.append( Item(channel=__channel__, title="HOT", action="lista", url=host+'/hot'))
    itemlist.append( Item(channel=__channel__, title="TOP DEL DIA", action="lista", url=host+'/to-day'))
    itemlist.append( Item(channel=__channel__, title="CATEGORIAS", action="categorias", url=host))
    return itemlist
    
def lista(item):
    
    if item.url=="":
        item.url = host
    
    logger.info("pelisalacarta.channels.javuncen lista")
    itemlist = []
    data = scrapertools.cache_page(item.url)
    patron ='<a class="main-thumb" href="([^"]+)" title="([^"]+)">.*?<img width="160px" height="210px" src="([^"]+)" alt'
    matches = re.compile(patron,re.DOTALL).findall(data)
    
    for scrapedurl, scrapedtitle, scrapedthumbnail in matches:
       datas = scrapertools.cache_page(scrapedurl)
       url = scrapertools.find_single_match(datas,'<a href="([^"]+)" class="bigthumb pull-left">')
       title = scrapedtitle.decode('utf-8')
       thumbnail = scrapedthumbnail
       fanart = scrapertools.find_single_match(datas,'<img src="([^"]+)" title=.*? alt=')
        
       if (DEBUG): logger.info("title=["+title+"], url=["+url+"], thumbnail=["+thumbnail+"])")
       itemlist.append( Item(channel=__channel__, action="findvideos" ,title=title , url=url, thumbnail=thumbnail, fanart=fanart ))
        
##Paginacion
    title=''
    siguiente = scrapertools.find_single_match(data,'<a href="([^"]+)">Next<\/a>')
    ultima = scrapertools.find_single_match(data,'<a href="([^"]+)">End<\/a>')
    if siguiente != ultima:
       titlen = 'Pagina Siguiente >>> '
       fanart = ''
       itemlist.append(Item(channel = __channel__, action = "lista", title =titlen, url = siguiente, fanart = fanart))
    return itemlist

#    

def findvideos(item):
    logger.info ("pelisalacarta.channels.javuncen findvideos")
    itemlist=[]
    data1=scrapertools.cache_page(item.url)
    patron ='<div class="row"><div class="col-md-2 server-name"><strong>.*?<\/strong><\/div><div class="col-md-10"><ul class="episodes"><li.*?<a href="([^"]+)">.*?<\/a>'
    matches = re.compile(patron,re.DOTALL).findall(data1)
    
    for scrapedurl in matches:
       datas = scrapertools.cache_page(scrapedurl)
       url = scrapedurl
       from core import servertools
       itemlist.extend(servertools.find_video_items(data=datas))
       for videoitem in itemlist:
          videoitem.channel=__channel__
          videoitem.action="play"
          videoitem.folder=False
          videoitem.fanart =item.fanart
          videoitem.thumbnail = item.thumbnail
          videoitem.title = item.title+" "+videoitem.server

    data=scrapertools.cache_page(item.url)
    patron ='{label: "([^"]+)", file: "([^"]+)","type":"video\/mp4".*?}'
    matches = re.compile(patron,re.DOTALL).findall(data1)
    
    for scrapedcalidad, scrapedurl in matches:
       url = scrapedurl
       title = item.title+' ('+scrapedcalidad+' )'
       thumbnail = item.thumbnail
       fanart=item.fanart
       if (DEBUG): logger.info("title=["+title+"], url=["+url+"], thumbnail=["+thumbnail+"])")
       itemlist.append( Item(channel=__channel__, action="play" , title=title ,fulltitle = item.title, url=url, thumbnail=thumbnail,fanart =fanart))

    return itemlist
    
def categorias(item):
    logger.info ("pelisalacarta.channels.javuncen categorias")
    itemlist=[]
    data = scrapertools.cache_page(item.url)
    patron ='<li><h3 class="title-menu"><a href="http:\/\/javuncen\.me\/category\/([^"]+)" title="([^"]+)">.*?<\/a><\/h3>'
    matches = re.compile(patron,re.DOTALL).findall(data) 
    
    for scrapedurl, scrapedtitle in matches:
       url='http://javuncen.me/category/'+scrapedurl
       title = scrapedtitle
       itemlist.append( Item(channel=__channel__, action="lista" , title=title, url=url))
    return itemlist   
    


                                 
        
