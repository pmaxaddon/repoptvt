script.module.pyrrent2http
==========================

This add-on is engine for [plugin.video.torrenter](https://github.com/DiMartinoXBMC/plugin.video.torrenter) 

This add-on can be used to stream media files from torrents without need to download entire files.
