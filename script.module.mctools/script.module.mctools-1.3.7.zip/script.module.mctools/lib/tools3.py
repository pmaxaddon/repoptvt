# coding: utf-8
from browser import *
from xbmc import translatePath

from ehp import *
from settings import *
from storage import *

__author__ = 'Mancuniancol'

# initialization
Html()
Browser()
Settings()
storage = Storage(translatePath('special://profile/addon_data/%s/' % Settings.idAddon))


# open the images from /resources/images
def dir_images(value):
    image_file = os.path.join(Settings.path_folder, 'resources', 'images', value)
    if not os.path.isfile(image_file):
        image_file = Settings.icon
    return image_file


# Convert all the &# codes to char, remove extra-space and normalize
def uncode_name(name):
    from HTMLParser import HTMLParser
    name = name.replace('<![CDATA[', '').replace(']]', '')
    name = HTMLParser().unescape(name)
    return name


def get_playable_link(page):
    # exceptionsList = Storage(settings.storageName.replace(".txt", "-exceptions.txt"))
    # result = page
    # settings.debug(result)
    # if 'divxatope' in page:
    #     page = page.replace('/descargar/', '/torrent/')
    #     result = page
    # isLink = True
    # settings.debug(exceptionsList.database)
    # for exception in exceptionsList.database:
    #     if exception in page:
    #         isLink = False
    #         break
    # if page.startswith("http") and isLink:
    #     # exceptions
    #     settings.debug(result)
    #     # download page
    #     try:
    #         response = browser.get(page, verify=False)
    #         data = normalize(response.text)
    #         settings.debug(response.headers)
    #         if 'text/html' in response.headers.get("content-type", ""):
    #             content = re.findall('magnet:\?[^\'"\s<>\[\]]+', data)
    #             if content != None and len(content) > 0:
    #                 result = content[0]
    #             else:
    #                 content = re.findall('/download\?token=[A-Za-z0-9%]+', data)
    #                 if content != None and len(content) > 0:
    #                     result = settings.value["urlAddress"] + content[0]
    #                 else:
    #                     content = re.findall('/telechargement/[a-z0-9-_.]+', data)  #cpasbien
    #                     if content != None and len(content) > 0:
    #                         result = settings.value["urlAddress"] + content[0]
    #                     else:
    #                         content = re.findall('https?:[^\'"\s<>\[\]]+torrent', data)
    #                         if content != None and len(content) > 0:
    #                             result = content[0]
    #         else:
    #             exceptionsList.add(re.search("^https?:\/\/(.*?)/", page).group(1))
    #             exceptionsList.save()
    #     except:
    #         pass
    # settings.log(result)
    # return result
    return page
